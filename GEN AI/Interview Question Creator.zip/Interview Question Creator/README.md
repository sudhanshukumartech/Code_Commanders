# Interview-Question-Creator-Project

### How to run?

1. Create an environment

```bash
conda create -n interview python=3.10 -y


conda activate interview

```

2. install requirements

```bash
pip install -r requirements.txt
```
